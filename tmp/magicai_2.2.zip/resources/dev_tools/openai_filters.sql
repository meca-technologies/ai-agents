INSERT INTO `openai_filters` (`id`, `name`) VALUES
(1, 'blog'),
(2, 'ecommerce'),
(3, 'development'),
(4, 'advertisement'),
(5, 'Custom'),
(6, 'social media');
