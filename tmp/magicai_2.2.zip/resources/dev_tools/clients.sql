INSERT INTO `clients` (`id`, `avatar`, `alt`, `title`, `created_at`, `updated_at`) VALUES
(1, '1c.svg', 'Envato', 'Envato', '2023-06-02 17:09:35', '2023-06-02 17:09:35'),
(2, '2c.svg', 'Envato', 'Envato', '2023-06-02 17:09:35', '2023-06-02 17:09:35'),
(4, '4c.svg', 'Envato', 'Envato', '2023-06-02 17:09:35', '2023-06-02 17:09:35'),
(5, '5c.svg', 'Envato', 'Envato', '2023-06-02 17:09:35', '2023-06-02 17:09:35'),
(6, '6c.svg', 'Envato', 'Envato', '2023-06-02 17:09:35', '2023-06-02 17:09:35');
