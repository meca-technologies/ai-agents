INSERT INTO `frontend_who_is_for` (`id`, `title`, `color`, `created_at`, `updated_at`) VALUES
(1, 'Digital Agencies', 'orange', '2023-06-02 13:16:34', '2023-06-02 10:38:34'),
(2, 'Product Designers', 'purple', '2023-06-02 13:16:34', '2023-06-02 13:16:34'),
(3, 'Enterpreneurs', 'teal', '2023-06-02 13:16:34', '2023-06-02 13:16:34'),
(4, 'Copywriters', 'blue', '2023-06-02 13:16:34', '2023-06-02 13:16:34'),
(5, 'Digital Marketers', 'green', '2023-06-02 13:16:34', '2023-06-02 13:16:34'),
(6, 'Developers', 'red', '2023-06-02 13:16:34', '2023-06-02 13:16:34');
