INSERT INTO `howitworks` (`id`, `order`, `title`, `created_at`, `updated_at`) VALUES
(1, 1, 'Simply explain what your content is about and adjust settings according to your needs.', '2023-06-02 08:41:26', '2023-06-02 08:41:26'),
(2, 2, 'Simply input some basic information or keywords about your brand or product, and let our AI algorithms do the rest.', '2023-06-02 08:41:34', '2023-06-02 08:41:34'),
(3, 3, 'View, edit or export your result with a few clicks. And you’re done!', '2023-06-02 08:41:41', '2023-06-02 08:41:41');
